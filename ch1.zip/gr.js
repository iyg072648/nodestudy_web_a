const user = "홍길동";

const hello = (name) => {
    console.log(`${name}님, 안녕하세요`);
}

hello(user);