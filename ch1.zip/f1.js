// function greeting(name){
//     console.log(`${name}님 안녕하세요`)
// }

// greeting("홍길동");
// greeting("홍이동");
// greeting("홍삼동");

(function (a,b){
    console.log(`두 수의 합 : ${a+b}`);
})(100,200)


let sum1 =(a,b) => a+b;
console.log(sum1(100,200));

// let hi =() => {return `안녕하세요`};
// console.log(hi());

// let hi1 =() => `안녕하세요`;
// console.log(hi1());
